# API Financeiro - Sistema de Gestão de Clube de Futebol

API responsável pelo gerenciamento financeiro do clube, permitindo controle de receitas, despesas e patrocinadores.

## Tecnologias Utilizadas

- Java 17
- Spring Boot 3
- Spring Security
- JWT
- Spring Data JPA
- MySQL
- Swagger / OpenAPI
- Maven

---

# Estrutura do Projeto

```txt
src/main/java/br/com/clubefutebol/financeiro

├── controller
├── model
│   ├── entity
│   ├── request
│   └── response
│
├── repository
├── security
├── service
```

### entity

Classes mapeadas no banco:

- Usuario
- Receita
- Despesa
- Patrocinador
- Role

### request

Objetos recebidos pela API:

- LoginRequest
- UsuarioRequest
- ReceitaRequest
- DespesaRequest
- PatrocinadorRequest

### response

Objetos retornados:

- LoginResponse
- UsuarioResponse
- ReceitaResponse
- DespesaResponse
- PatrocinadorResponse

---

# Banco de Dados

```sql
CREATE DATABASE clube_futebol;
USE clube_futebol;
```

```sql
CREATE TABLE patrocinador(
id BIGINT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(100),
empresa VARCHAR(100),
telefone VARCHAR(20)
);

CREATE TABLE receita(
id BIGINT AUTO_INCREMENT PRIMARY KEY,
descricao VARCHAR(150),
valor DECIMAL(10,2),
data_receita DATE,
patrocinador_id BIGINT,

FOREIGN KEY (patrocinador_id)
REFERENCES patrocinador(id)
);

CREATE TABLE despesa(
id BIGINT AUTO_INCREMENT PRIMARY KEY,
descricao VARCHAR(150),
valor DECIMAL(10,2),
data_despesa DATE
);

CREATE TABLE usuario_financeiro(
id BIGINT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(100),
email VARCHAR(100) UNIQUE,
senha VARCHAR(255),
role VARCHAR(50)
);
```

---

# URL Base

```txt
http://localhost:3000
```

---

# Autenticação JWT

Após login a API retorna:

```json
{
   "token":"eyJhb..."
}
```

Enviar em todas as rotas protegidas:

```txt
Authorization: Bearer TOKEN
```

---

# AUTH

## Registrar usuário

### POST

```txt
/auth/register
```

### Payload

```json
{
   "nome":"Nayana",
   "email":"nayana@email.com",
   "senha":"123456",
   "role":"ADMIN"
}
```

### Sucesso

Status:

```txt
201 Created
```

Resposta:

```json
{
   "id":1,
   "nome":"Nayana",
   "email":"nayana@email.com",
   "role":"ADMIN"
}
```

### Erro

Status:

```txt
400 Bad Request
```

```json
{
   "erro":"Email já cadastrado"
}
```

---

## Login

### POST

```txt
/auth/login
```

### Payload

```json
{
   "email":"nayana@email.com",
   "senha":"123456"
}
```

### Sucesso

```txt
200 OK
```

```json
{
   "token":"eyJhb..."
}
```

### Erro

```txt
401 Unauthorized
```

```json
{
   "erro":"Email ou senha inválidos"
}
```

---

# PATROCINADOR

## Cadastrar patrocinador

### POST

```txt
/patrocinadores
```

### Payload

```json
{
   "nome":"Nike",
   "empresa":"Nike Brasil",
   "telefone":"11999999999"
}
```

### Sucesso

```txt
201 Created
```

```json
{
   "id":1,
   "nome":"Nike",
   "empresa":"Nike Brasil",
   "telefone":"11999999999"
}
```

---

## Listar patrocinadores

### GET

```txt
/patrocinadores
```

### Sucesso

```json
[
   {
      "id":1,
      "nome":"Nike"
   }
]
```

---

# RECEITAS

## Cadastrar receita

### POST

```txt
/receitas
```

### Payload

```json
{
   "descricao":"Patrocínio Master",
   "valor":250000,
   "dataReceita":"2026-05-21",
   "patrocinadorId":1
}
```

### Sucesso

```txt
201 Created
```

```json
{
   "id":1,
   "descricao":"Patrocínio Master",
   "valor":250000,
   "dataReceita":"2026-05-21",
   "patrocinador":"Nike"
}
```

### Erro

```txt
404 Not Found
```

```json
{
   "erro":"Patrocinador não encontrado"
}
```

---

## Listar receitas

### GET

```txt
/receitas
```

Resposta:

```json
[
   {
      "id":1,
      "descricao":"Patrocínio Master",
      "valor":250000
   }
]
```

---

# DESPESAS

## Cadastrar despesa

### POST

```txt
/despesas
```

Payload:

```json
{
   "descricao":"Compra de uniformes",
   "valor":5000,
   "dataDespesa":"2026-05-21"
}
```

### Sucesso

```txt
201 Created
```

```json
{
   "id":1,
   "descricao":"Compra de uniformes",
   "valor":5000
}
```

---

## Listar despesas

### GET

```txt
/despesas
```

Resposta:

```json
[
   {
      "id":1,
      "descricao":"Compra de uniformes"
   }
]
```

---

# Erros Globais

## 401 Unauthorized

```json
{
   "erro":"Token inválido"
}
```

## 403 Forbidden

```json
{
   "erro":"Acesso negado"
}
```

## 404 Not Found

```json
{
   "erro":"Recurso não encontrado"
}
```

## 500 Internal Server Error

```json
{
   "erro":"Erro interno do servidor"
}
```

---

# Swagger

Documentação automática:

http://localhost:3000/swagger-ui/index.html
package br.com.clubefutebol.financeiro.service;

import br.com.clubefutebol.financeiro.model.entity.Despesa;
import br.com.clubefutebol.financeiro.model.request.DespesaRequest;
import br.com.clubefutebol.financeiro.model.response.DespesaResponse;
import br.com.clubefutebol.financeiro.repository.DespesaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DespesaService {

    private final DespesaRepository repository;

    public DespesaService(DespesaRepository repository) {
        this.repository = repository;
    }

    public DespesaResponse cadastrar(DespesaRequest request) {
        Despesa despesa = new Despesa();
        preencherDados(despesa, request);
        return toResponse(repository.save(despesa));
    }

    public List<DespesaResponse> listar() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    public DespesaResponse buscar(Long id) {
        return toResponse(buscarEntidade(id));
    }

    public DespesaResponse atualizar(Long id, DespesaRequest request) {
        Despesa despesa = buscarEntidade(id);
        preencherDados(despesa, request);
        return toResponse(repository.save(despesa));
    }

    public void deletar(Long id) {
        repository.delete(buscarEntidade(id));
    }

    private void preencherDados(Despesa despesa, DespesaRequest request) {
        despesa.setDescricao(request.getDescricao());
        despesa.setValor(request.getValor());
        despesa.setDataDespesa(request.getDataDespesa());
    }

    private Despesa buscarEntidade(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Despesa não encontrada"));
    }

    private DespesaResponse toResponse(Despesa d) {
        return new DespesaResponse(d.getId(), d.getDescricao(), d.getValor(), d.getDataDespesa());
    }
}

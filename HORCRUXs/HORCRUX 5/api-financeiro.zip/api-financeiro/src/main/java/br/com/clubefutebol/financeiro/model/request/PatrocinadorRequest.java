package br.com.clubefutebol.financeiro.model.request;

public class PatrocinadorRequest {
    private String nome;
    private String empresa;
    private String telefone;

    public String getNome() { return nome; }
    public String getEmpresa() { return empresa; }
    public String getTelefone() { return telefone; }

    public void setNome(String nome) { this.nome = nome; }
    public void setEmpresa(String empresa) { this.empresa = empresa; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
}

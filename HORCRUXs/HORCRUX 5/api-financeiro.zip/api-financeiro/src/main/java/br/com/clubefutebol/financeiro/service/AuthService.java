package br.com.clubefutebol.financeiro.service;

import br.com.clubefutebol.financeiro.model.entity.Role;
import br.com.clubefutebol.financeiro.model.entity.Usuario;
import br.com.clubefutebol.financeiro.model.request.LoginRequest;
import br.com.clubefutebol.financeiro.model.request.UsuarioRequest;
import br.com.clubefutebol.financeiro.model.response.LoginResponse;
import br.com.clubefutebol.financeiro.model.response.UsuarioResponse;
import br.com.clubefutebol.financeiro.repository.UsuarioRepository;
import br.com.clubefutebol.financeiro.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public UsuarioResponse registrar(UsuarioRequest request) {
        if (usuarioRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email já cadastrado");
        }

        Usuario usuario = new Usuario();
        usuario.setNome(request.getNome());
        usuario.setEmail(request.getEmail());
        usuario.setSenha(passwordEncoder.encode(request.getSenha()));

        if (request.getRole() == null || request.getRole().isBlank()) {
            usuario.setRole(Role.ADMIN);
        } else {
            usuario.setRole(Role.valueOf(request.getRole().toUpperCase()));
        }

        Usuario salvo = usuarioRepository.save(usuario);
        return new UsuarioResponse(salvo.getId(), salvo.getNome(), salvo.getEmail(), salvo.getRole());
    }

    public LoginResponse login(LoginRequest request) {
        Usuario usuario = usuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Email ou senha inválidos"));

        boolean senhaCorreta = passwordEncoder.matches(request.getSenha(), usuario.getSenha());

        if (!senhaCorreta) {
            throw new RuntimeException("Email ou senha inválidos");
        }

        String token = jwtService.gerarToken(usuario);
        return new LoginResponse(token);
    }
}

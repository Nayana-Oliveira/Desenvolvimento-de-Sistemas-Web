package br.com.clubefutebol.financeiro.model.response;

import java.math.BigDecimal;
import java.time.LocalDate;

public class DespesaResponse {
    private Long id;
    private String descricao;
    private BigDecimal valor;
    private LocalDate dataDespesa;

    public DespesaResponse(Long id, String descricao, BigDecimal valor, LocalDate dataDespesa) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
        this.dataDespesa = dataDespesa;
    }

    public Long getId() { return id; }
    public String getDescricao() { return descricao; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getDataDespesa() { return dataDespesa; }
}

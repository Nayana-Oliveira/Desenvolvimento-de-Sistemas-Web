package br.com.clubefutebol.financeiro.model.entity;

public enum Role {
    ADMIN,
    FUNCIONARIO,
    TREINADOR
}

package br.com.clubefutebol.financeiro.model.request;

import java.math.BigDecimal;
import java.time.LocalDate;

public class DespesaRequest {
    private String descricao;
    private BigDecimal valor;
    private LocalDate dataDespesa;

    public String getDescricao() { return descricao; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getDataDespesa() { return dataDespesa; }

    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public void setDataDespesa(LocalDate dataDespesa) { this.dataDespesa = dataDespesa; }
}

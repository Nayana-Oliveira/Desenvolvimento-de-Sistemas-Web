package br.com.clubefutebol.financeiro.model.response;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ReceitaResponse {
    private Long id;
    private String descricao;
    private BigDecimal valor;
    private LocalDate dataReceita;
    private Long patrocinadorId;
    private String patrocinadorNome;

    public ReceitaResponse(Long id, String descricao, BigDecimal valor, LocalDate dataReceita, Long patrocinadorId, String patrocinadorNome) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
        this.dataReceita = dataReceita;
        this.patrocinadorId = patrocinadorId;
        this.patrocinadorNome = patrocinadorNome;
    }

    public Long getId() { return id; }
    public String getDescricao() { return descricao; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getDataReceita() { return dataReceita; }
    public Long getPatrocinadorId() { return patrocinadorId; }
    public String getPatrocinadorNome() { return patrocinadorNome; }
}

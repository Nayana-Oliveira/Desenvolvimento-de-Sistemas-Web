package br.com.clubefutebol.financeiro.service;

import br.com.clubefutebol.financeiro.model.entity.Patrocinador;
import br.com.clubefutebol.financeiro.model.entity.Receita;
import br.com.clubefutebol.financeiro.model.request.ReceitaRequest;
import br.com.clubefutebol.financeiro.model.response.ReceitaResponse;
import br.com.clubefutebol.financeiro.repository.PatrocinadorRepository;
import br.com.clubefutebol.financeiro.repository.ReceitaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReceitaService {

    private final ReceitaRepository receitaRepository;
    private final PatrocinadorRepository patrocinadorRepository;

    public ReceitaService(ReceitaRepository receitaRepository, PatrocinadorRepository patrocinadorRepository) {
        this.receitaRepository = receitaRepository;
        this.patrocinadorRepository = patrocinadorRepository;
    }

    public ReceitaResponse cadastrar(ReceitaRequest request) {
        Receita receita = new Receita();
        preencherDados(receita, request);
        return toResponse(receitaRepository.save(receita));
    }

    public List<ReceitaResponse> listar() {
        return receitaRepository.findAll().stream().map(this::toResponse).toList();
    }

    public ReceitaResponse buscar(Long id) {
        return toResponse(buscarEntidade(id));
    }

    public ReceitaResponse atualizar(Long id, ReceitaRequest request) {
        Receita receita = buscarEntidade(id);
        preencherDados(receita, request);
        return toResponse(receitaRepository.save(receita));
    }

    public void deletar(Long id) {
        receitaRepository.delete(buscarEntidade(id));
    }

    private void preencherDados(Receita receita, ReceitaRequest request) {
        receita.setDescricao(request.getDescricao());
        receita.setValor(request.getValor());
        receita.setDataReceita(request.getDataReceita());

        if (request.getPatrocinadorId() != null) {
            Patrocinador patrocinador = patrocinadorRepository.findById(request.getPatrocinadorId())
                    .orElseThrow(() -> new RuntimeException("Patrocinador não encontrado"));
            receita.setPatrocinador(patrocinador);
        } else {
            receita.setPatrocinador(null);
        }
    }

    private Receita buscarEntidade(Long id) {
        return receitaRepository.findById(id).orElseThrow(() -> new RuntimeException("Receita não encontrada"));
    }

    private ReceitaResponse toResponse(Receita r) {
        Long patrocinadorId = r.getPatrocinador() != null ? r.getPatrocinador().getId() : null;
        String patrocinadorNome = r.getPatrocinador() != null ? r.getPatrocinador().getNome() : null;
        return new ReceitaResponse(r.getId(), r.getDescricao(), r.getValor(), r.getDataReceita(), patrocinadorId, patrocinadorNome);
    }
}

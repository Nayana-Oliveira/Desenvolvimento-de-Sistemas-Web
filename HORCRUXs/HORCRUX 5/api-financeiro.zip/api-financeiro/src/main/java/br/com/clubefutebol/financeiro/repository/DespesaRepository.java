package br.com.clubefutebol.financeiro.repository;

import br.com.clubefutebol.financeiro.model.entity.Despesa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DespesaRepository extends JpaRepository<Despesa, Long> {
}

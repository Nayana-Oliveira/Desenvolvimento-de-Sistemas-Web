package br.com.clubefutebol.financeiro.controller;

import br.com.clubefutebol.financeiro.model.request.LoginRequest;
import br.com.clubefutebol.financeiro.model.request.UsuarioRequest;
import br.com.clubefutebol.financeiro.model.response.LoginResponse;
import br.com.clubefutebol.financeiro.model.response.UsuarioResponse;
import br.com.clubefutebol.financeiro.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody UsuarioRequest request) {
        try {
            UsuarioResponse response = service.registrar(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("erro", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            LoginResponse response = service.login(request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("erro", e.getMessage()));
        }
    }
}

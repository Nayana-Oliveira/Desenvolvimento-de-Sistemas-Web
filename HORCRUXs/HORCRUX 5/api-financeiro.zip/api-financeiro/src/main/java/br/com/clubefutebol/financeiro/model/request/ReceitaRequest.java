package br.com.clubefutebol.financeiro.model.request;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ReceitaRequest {
    private String descricao;
    private BigDecimal valor;
    private LocalDate dataReceita;
    private Long patrocinadorId;

    public String getDescricao() { return descricao; }
    public BigDecimal getValor() { return valor; }
    public LocalDate getDataReceita() { return dataReceita; }
    public Long getPatrocinadorId() { return patrocinadorId; }

    public void setDescricao(String descricao) { this.descricao = descricao; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public void setDataReceita(LocalDate dataReceita) { this.dataReceita = dataReceita; }
    public void setPatrocinadorId(Long patrocinadorId) { this.patrocinadorId = patrocinadorId; }
}

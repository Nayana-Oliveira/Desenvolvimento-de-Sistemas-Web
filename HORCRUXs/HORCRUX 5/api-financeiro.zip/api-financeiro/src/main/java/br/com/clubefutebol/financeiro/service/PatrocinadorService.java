package br.com.clubefutebol.financeiro.service;

import br.com.clubefutebol.financeiro.model.entity.Patrocinador;
import br.com.clubefutebol.financeiro.model.request.PatrocinadorRequest;
import br.com.clubefutebol.financeiro.model.response.PatrocinadorResponse;
import br.com.clubefutebol.financeiro.repository.PatrocinadorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatrocinadorService {

    private final PatrocinadorRepository repository;

    public PatrocinadorService(PatrocinadorRepository repository) {
        this.repository = repository;
    }

    public PatrocinadorResponse cadastrar(PatrocinadorRequest request) {
        Patrocinador patrocinador = new Patrocinador();
        patrocinador.setNome(request.getNome());
        patrocinador.setEmpresa(request.getEmpresa());
        patrocinador.setTelefone(request.getTelefone());
        return toResponse(repository.save(patrocinador));
    }

    public List<PatrocinadorResponse> listar() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    public PatrocinadorResponse buscar(Long id) {
        return toResponse(buscarEntidade(id));
    }

    public PatrocinadorResponse atualizar(Long id, PatrocinadorRequest request) {
        Patrocinador patrocinador = buscarEntidade(id);
        patrocinador.setNome(request.getNome());
        patrocinador.setEmpresa(request.getEmpresa());
        patrocinador.setTelefone(request.getTelefone());
        return toResponse(repository.save(patrocinador));
    }

    public void deletar(Long id) {
        repository.delete(buscarEntidade(id));
    }

    private Patrocinador buscarEntidade(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Patrocinador não encontrado"));
    }

    private PatrocinadorResponse toResponse(Patrocinador p) {
        return new PatrocinadorResponse(p.getId(), p.getNome(), p.getEmpresa(), p.getTelefone());
    }
}

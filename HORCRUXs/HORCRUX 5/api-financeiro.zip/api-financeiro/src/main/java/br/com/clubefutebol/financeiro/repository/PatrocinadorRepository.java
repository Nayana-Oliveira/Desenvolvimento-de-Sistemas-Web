package br.com.clubefutebol.financeiro.repository;

import br.com.clubefutebol.financeiro.model.entity.Patrocinador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatrocinadorRepository extends JpaRepository<Patrocinador, Long> {
}

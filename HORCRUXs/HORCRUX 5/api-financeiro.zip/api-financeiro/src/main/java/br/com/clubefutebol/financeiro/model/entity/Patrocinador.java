package br.com.clubefutebol.financeiro.model.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "patrocinador")
public class Patrocinador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String empresa;
    private String telefone;

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getEmpresa() { return empresa; }
    public String getTelefone() { return telefone; }

    public void setId(Long id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setEmpresa(String empresa) { this.empresa = empresa; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
}

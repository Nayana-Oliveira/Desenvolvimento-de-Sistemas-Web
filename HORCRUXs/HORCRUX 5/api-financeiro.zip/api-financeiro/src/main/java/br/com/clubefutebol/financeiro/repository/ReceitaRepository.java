package br.com.clubefutebol.financeiro.repository;

import br.com.clubefutebol.financeiro.model.entity.Receita;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReceitaRepository extends JpaRepository<Receita, Long> {
}

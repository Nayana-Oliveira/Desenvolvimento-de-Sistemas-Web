package br.com.clubefutebol.financeiro.model.response;

public class PatrocinadorResponse {
    private Long id;
    private String nome;
    private String empresa;
    private String telefone;

    public PatrocinadorResponse(Long id, String nome, String empresa, String telefone) {
        this.id = id;
        this.nome = nome;
        this.empresa = empresa;
        this.telefone = telefone;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getEmpresa() { return empresa; }
    public String getTelefone() { return telefone; }
}

package br.com.clubefutebol.financeiro.model.request;

public class UsuarioRequest {
    private String nome;
    private String email;
    private String senha;
    private String role;

    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public String getSenha() { return senha; }
    public String getRole() { return role; }

    public void setNome(String nome) { this.nome = nome; }
    public void setEmail(String email) { this.email = email; }
    public void setSenha(String senha) { this.senha = senha; }
    public void setRole(String role) { this.role = role; }
}

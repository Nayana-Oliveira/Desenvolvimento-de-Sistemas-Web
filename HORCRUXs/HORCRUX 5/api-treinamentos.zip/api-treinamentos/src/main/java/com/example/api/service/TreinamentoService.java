package com.example.api.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.api.models.entity.Treinamento;
import com.example.api.repository.TreinamentoRepository;

@Service
public class TreinamentoService {
    private final TreinamentoRepository repository;

    public TreinamentoService(TreinamentoRepository repository) {
        this.repository = repository;
    }

    public Treinamento salvar(Treinamento obj) {
        return repository.save(obj);
    }

    public List<Treinamento> listar() {
        return repository.findAll();
    }

    public Treinamento buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado"));
    }

    public Treinamento atualizar(Long id, Treinamento obj) {
        obj.setId(id);
        return repository.save(obj);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}

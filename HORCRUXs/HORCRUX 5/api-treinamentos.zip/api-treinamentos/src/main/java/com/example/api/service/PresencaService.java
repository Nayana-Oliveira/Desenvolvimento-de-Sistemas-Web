package com.example.api.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.api.models.entity.Presenca;
import com.example.api.repository.PresencaRepository;


@Service
public class PresencaService {
    private final PresencaRepository repository;

    public PresencaService(PresencaRepository repository) {
        this.repository = repository;
    }

    public Presenca salvar(Presenca obj) {
        return repository.save(obj);
    }

    public List<Presenca> listar() {
        return repository.findAll();
    }

    public Presenca buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado"));
    }

    public Presenca atualizar(Long id, Presenca obj) {
        obj.setId(id);
        return repository.save(obj);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}

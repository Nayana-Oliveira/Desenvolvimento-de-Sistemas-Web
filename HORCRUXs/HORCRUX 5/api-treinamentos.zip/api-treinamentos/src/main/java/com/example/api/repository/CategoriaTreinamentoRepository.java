package com.example.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.api.models.entity.CategoriaTreinamento;

public interface CategoriaTreinamentoRepository extends JpaRepository<CategoriaTreinamento, Long> {
}

package com.example.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.models.entity.CategoriaTreinamento;
import com.example.api.service.CategoriaTreinamentoService;


@RestController
@RequestMapping("/categorias-treinamento")
public class CategoriaTreinamentoController {
    private final CategoriaTreinamentoService service;

    public CategoriaTreinamentoController(CategoriaTreinamentoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CategoriaTreinamento> cadastrar(@RequestBody CategoriaTreinamento obj) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj));
    }

    @GetMapping
    public ResponseEntity<List<CategoriaTreinamento>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriaTreinamento> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscar(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategoriaTreinamento> atualizar(@PathVariable Long id,
            @RequestBody CategoriaTreinamento obj) {
        return ResponseEntity.ok(service.atualizar(id, obj));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        service.deletar(id);
        return ResponseEntity.noContent().build();
    }
}

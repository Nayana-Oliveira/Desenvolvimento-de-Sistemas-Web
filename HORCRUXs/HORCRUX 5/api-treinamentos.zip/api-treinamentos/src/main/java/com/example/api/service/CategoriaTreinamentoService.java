package com.example.api.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.api.models.entity.CategoriaTreinamento;
import com.example.api.repository.CategoriaTreinamentoRepository;

@Service
public class CategoriaTreinamentoService {
    private final CategoriaTreinamentoRepository repository;

    public CategoriaTreinamentoService(CategoriaTreinamentoRepository repository) {
        this.repository = repository;
    }

    public CategoriaTreinamento salvar(CategoriaTreinamento obj) {
        return repository.save(obj);
    }

    public List<CategoriaTreinamento> listar() {
        return repository.findAll();
    }

    public CategoriaTreinamento buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado"));
    }

    public CategoriaTreinamento atualizar(Long id, CategoriaTreinamento obj) {
        obj.setId(id);
        return repository.save(obj);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}

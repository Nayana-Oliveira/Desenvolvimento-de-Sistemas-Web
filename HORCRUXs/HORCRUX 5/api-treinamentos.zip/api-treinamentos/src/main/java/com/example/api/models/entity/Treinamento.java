package com.example.api.models.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "treinamento")
public class Treinamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String descricao;
    @Column(name = "data_treinamento")
    private LocalDate dataTreinamento;
    private LocalTime horario;

    @ManyToOne
    @JoinColumn(name = "categoria_id")
    private CategoriaTreinamento categoria;

    public CategoriaTreinamento getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaTreinamento categoria) {
        this.categoria = categoria;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getDataTreinamento() {
        return dataTreinamento;
    }

    public void setDataTreinamento(LocalDate dataTreinamento) {
        this.dataTreinamento = dataTreinamento;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }
}

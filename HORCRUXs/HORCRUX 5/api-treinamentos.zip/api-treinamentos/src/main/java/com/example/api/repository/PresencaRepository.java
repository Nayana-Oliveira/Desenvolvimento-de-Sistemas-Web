package com.example.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.api.models.entity.Presenca;

public interface PresencaRepository extends JpaRepository<Presenca, Long> {
}

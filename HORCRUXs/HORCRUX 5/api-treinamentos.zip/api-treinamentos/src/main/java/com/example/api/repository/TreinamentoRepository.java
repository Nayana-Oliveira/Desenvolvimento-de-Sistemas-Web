package com.example.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.api.models.entity.Treinamento;

public interface TreinamentoRepository extends JpaRepository<Treinamento, Long> {
}

package com.example.api.models.entity;

public enum Role {
    ADMIN, FUNCIONARIO, TREINADOR
}

package com.example.api.models.request;

import com.example.api.models.entity.Role;

public record RegisterRequest(String nome, String email, String senha, Role role) {
}

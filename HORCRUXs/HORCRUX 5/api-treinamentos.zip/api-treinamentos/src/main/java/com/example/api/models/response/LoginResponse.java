package com.example.api.models.response;

public record LoginResponse(String token) {
}

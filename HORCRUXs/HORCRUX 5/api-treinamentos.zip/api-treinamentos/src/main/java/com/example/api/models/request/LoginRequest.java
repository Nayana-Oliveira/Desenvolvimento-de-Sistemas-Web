package com.example.api.models.request;

public record LoginRequest(String email, String senha) {
}

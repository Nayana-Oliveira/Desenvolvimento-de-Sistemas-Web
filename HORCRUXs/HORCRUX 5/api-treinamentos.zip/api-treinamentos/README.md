# Documentação OpenAPI — API de Treinamentos

## Visão Geral

API REST desenvolvida em Spring Boot para gerenciamento de categorias de treinamento, treinamentos e presenças de jogadores.

A aplicação utiliza autenticação com JWT. Os endpoints de autenticação ficam abertos, enquanto os endpoints de CRUD exigem envio do token no cabeçalho da requisição.

## Base URL

```txt
http://localhost:3000
```

## Autenticação

Após realizar login, a API retorna um token JWT. Esse token deve ser enviado nas próximas requisições protegidas usando o header:

```txt
Authorization: Bearer SEU_TOKEN_AQUI
```

## Fluxo recomendado de teste

1. Criar usuário em `/auth/register`
2. Fazer login em `/auth/login`
3. Copiar o token retornado
4. Enviar o token no header `Authorization`
5. Testar os CRUDs nesta ordem:
   - Categorias de treinamento
   - Treinamentos
   - Presenças

---

# Endpoints de Autenticação

## Criar usuário

### `POST /auth/register`

Cria uma nova conta de usuário no sistema.

### Body

```json
{
  "nome": "Gustavo",
  "email": "gustavo@email.com",
  "senha": "123456",
  "role": "ADMIN"
}
```

### Resposta de sucesso — `201 Created`

```json
{
  "id": 1,
  "nome": "Gustavo",
  "email": "gustavo@email.com",
  "role": "ADMIN"
}
```

### Possíveis erros

| Status | Motivo |
|---|---|
| 400 | Dados inválidos |
| 500 | Email duplicado ou erro interno |

---

## Login

### `POST /auth/login`

Realiza autenticação e retorna um token JWT.

### Body

```json
{
  "email": "gustavo@email.com",
  "senha": "123456"
}
```

### Resposta de sucesso — `200 OK`

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9..."
}
```

### Possíveis erros

| Status | Motivo |
|---|---|
| 401 | Credenciais inválidas |
| 403 | Usuário não autorizado |

---

# Endpoints de Categorias de Treinamento

## Criar categoria

### `POST /categorias-treinamento`

Cadastra uma nova categoria de treinamento.

### Segurança

Requer JWT.

### Body

```json
{
  "nome": "Treinamento Físico"
}
```

### Resposta de sucesso — `201 Created`

```json
{
  "id": 1,
  "nome": "Treinamento Físico"
}
```

---

## Listar categorias

### `GET /categorias-treinamento`

Retorna todas as categorias cadastradas.

### Segurança

Requer JWT.

### Resposta de sucesso — `200 OK`

```json
[
  {
    "id": 1,
    "nome": "Treinamento Físico"
  }
]
```

---

## Buscar categoria por ID

### `GET /categorias-treinamento/{id}`

Busca uma categoria específica pelo ID.

### Parâmetro de rota

| Parâmetro | Tipo | Descrição |
|---|---|---|
| id | Long | ID da categoria |

### Segurança

Requer JWT.

### Resposta de sucesso — `200 OK`

```json
{
  "id": 1,
  "nome": "Treinamento Físico"
}
```

### Resposta de erro — `404 Not Found`

```json
"Registro não encontrado"
```

---

## Atualizar categoria

### `PUT /categorias-treinamento/{id}`

Atualiza os dados de uma categoria existente.

### Segurança

Requer JWT.

### Body

```json
{
  "nome": "Treinamento Técnico"
}
```

### Resposta de sucesso — `200 OK`

```json
{
  "id": 1,
  "nome": "Treinamento Técnico"
}
```

---

## Excluir categoria

### `DELETE /categorias-treinamento/{id}`

Remove uma categoria do sistema.

### Segurança

Requer JWT.

### Resposta de sucesso — `204 No Content`

Sem corpo de resposta.

### Observação

Caso exista um treinamento vinculado à categoria, o banco pode impedir a exclusão por causa do relacionamento.

---

# Endpoints de Treinamentos

## Criar treinamento

### `POST /treinamentos`

Cadastra um novo treinamento vinculado a uma categoria.

### Segurança

Requer JWT.

### Body

```json
{
  "descricao": "Treino de resistência e velocidade",
  "dataTreinamento": "2026-05-21",
  "horario": "14:30:00",
  "categoria": {
    "id": 1
  }
}
```

### Resposta de sucesso — `201 Created`

```json
{
  "id": 1,
  "descricao": "Treino de resistência e velocidade",
  "dataTreinamento": "2026-05-21",
  "horario": "14:30:00",
  "categoria": {
    "id": 1,
    "nome": "Treinamento Físico"
  }
}
```

---

## Listar treinamentos

### `GET /treinamentos`

Retorna todos os treinamentos cadastrados.

### Segurança

Requer JWT.

### Resposta de sucesso — `200 OK`

```json
[
  {
    "id": 1,
    "descricao": "Treino de resistência e velocidade",
    "dataTreinamento": "2026-05-21",
    "horario": "14:30:00",
    "categoria": {
      "id": 1,
      "nome": "Treinamento Físico"
    }
  }
]
```

---

## Buscar treinamento por ID

### `GET /treinamentos/{id}`

Busca um treinamento específico pelo ID.

### Parâmetro de rota

| Parâmetro | Tipo | Descrição |
|---|---|---|
| id | Long | ID do treinamento |

### Segurança

Requer JWT.

### Resposta de sucesso — `200 OK`

```json
{
  "id": 1,
  "descricao": "Treino de resistência e velocidade",
  "dataTreinamento": "2026-05-21",
  "horario": "14:30:00",
  "categoria": {
    "id": 1,
    "nome": "Treinamento Físico"
  }
}
```

### Resposta de erro — `404 Not Found`

```json
"Registro não encontrado"
```

---

## Atualizar treinamento

### `PUT /treinamentos/{id}`

Atualiza os dados de um treinamento existente.

### Segurança

Requer JWT.

### Body

```json
{
  "descricao": "Treino atualizado",
  "dataTreinamento": "2026-05-22",
  "horario": "16:00:00",
  "categoria": {
    "id": 1
  }
}
```

### Resposta de sucesso — `200 OK`

```json
{
  "id": 1,
  "descricao": "Treino atualizado",
  "dataTreinamento": "2026-05-22",
  "horario": "16:00:00",
  "categoria": {
    "id": 1,
    "nome": "Treinamento Físico"
  }
}
```

---

## Excluir treinamento

### `DELETE /treinamentos/{id}`

Remove um treinamento do sistema.

### Segurança

Requer JWT.

### Resposta de sucesso — `204 No Content`

Sem corpo de resposta.

### Observação

Caso exista uma presença vinculada ao treinamento, o banco pode impedir a exclusão por causa do relacionamento.

---

# Endpoints de Presenças

## Criar presença

### `POST /presencas`

Cadastra a presença de um jogador em um treinamento.

### Segurança

Requer JWT.

### Body

```json
{
  "nomeJogador": "Neymar Jr",
  "presente": true,
  "treinamento": {
    "id": 1
  }
}
```

### Resposta de sucesso — `201 Created`

```json
{
  "id": 1,
  "nomeJogador": "Neymar Jr",
  "presente": true,
  "treinamento": {
    "id": 1,
    "descricao": "Treino de resistência e velocidade",
    "dataTreinamento": "2026-05-21",
    "horario": "14:30:00"
  }
}
```

---

## Listar presenças

### `GET /presencas`

Retorna todas as presenças cadastradas.

### Segurança

Requer JWT.

### Resposta de sucesso — `200 OK`

```json
[
  {
    "id": 1,
    "nomeJogador": "Neymar Jr",
    "presente": true,
    "treinamento": {
      "id": 1,
      "descricao": "Treino de resistência e velocidade",
      "dataTreinamento": "2026-05-21",
      "horario": "14:30:00"
    }
  }
]
```

---

## Buscar presença por ID

### `GET /presencas/{id}`

Busca uma presença específica pelo ID.

### Parâmetro de rota

| Parâmetro | Tipo | Descrição |
|---|---|---|
| id | Long | ID da presença |

### Segurança

Requer JWT.

### Resposta de sucesso — `200 OK`

```json
{
  "id": 1,
  "nomeJogador": "Neymar Jr",
  "presente": true,
  "treinamento": {
    "id": 1,
    "descricao": "Treino de resistência e velocidade",
    "dataTreinamento": "2026-05-21",
    "horario": "14:30:00"
  }
}
```

### Resposta de erro — `404 Not Found`

```json
"Registro não encontrado"
```

---

## Atualizar presença

### `PUT /presencas/{id}`

Atualiza os dados de uma presença existente.

### Segurança

Requer JWT.

### Body

```json
{
  "nomeJogador": "Vinicius Jr",
  "presente": false,
  "treinamento": {
    "id": 1
  }
}
```

### Resposta de sucesso — `200 OK`

```json
{
  "id": 1,
  "nomeJogador": "Vinicius Jr",
  "presente": false,
  "treinamento": {
    "id": 1,
    "descricao": "Treino de resistência e velocidade",
    "dataTreinamento": "2026-05-21",
    "horario": "14:30:00"
  }
}
```

---

## Excluir presença

### `DELETE /presencas/{id}`

Remove uma presença do sistema.

### Segurança

Requer JWT.

### Resposta de sucesso — `204 No Content`

Sem corpo de resposta.

---

# Códigos de Status Utilizados

| Status | Significado |
|---|---|
| 200 OK | Requisição executada com sucesso |
| 201 Created | Registro criado com sucesso |
| 204 No Content | Registro removido com sucesso |
| 401 Unauthorized | Token ausente ou inválido |
| 403 Forbidden | Acesso negado |
| 404 Not Found | Registro não encontrado |
| 500 Internal Server Error | Erro interno ou erro não tratado |

---

# Observações para Teste

## Ordem correta para criação

```txt
1. Criar categoria
2. Criar treinamento vinculado à categoria
3. Criar presença vinculada ao treinamento
```

## Ordem correta para exclusão

```txt
1. Excluir presenças
2. Excluir treinamentos
3. Excluir categorias
```

Essa ordem evita erros de chave estrangeira, pois treinamento depende de categoria e presença depende de treinamento.
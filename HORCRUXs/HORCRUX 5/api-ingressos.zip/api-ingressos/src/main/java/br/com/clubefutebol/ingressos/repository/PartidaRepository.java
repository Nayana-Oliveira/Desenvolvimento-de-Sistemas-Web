package br.com.clubefutebol.ingressos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.clubefutebol.ingressos.model.entity.Partida;

public interface PartidaRepository extends JpaRepository<Partida, Long> {
}

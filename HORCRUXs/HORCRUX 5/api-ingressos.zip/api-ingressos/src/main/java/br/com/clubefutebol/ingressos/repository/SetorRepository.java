package br.com.clubefutebol.ingressos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.clubefutebol.ingressos.model.entity.Setor;

public interface SetorRepository extends JpaRepository<Setor, Long> {
}

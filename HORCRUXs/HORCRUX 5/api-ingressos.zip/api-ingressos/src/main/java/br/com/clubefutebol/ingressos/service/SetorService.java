package br.com.clubefutebol.ingressos.service;

import br.com.clubefutebol.ingressos.model.entity.Setor;
import br.com.clubefutebol.ingressos.repository.SetorRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SetorService {

    private final SetorRepository repository;

    public SetorService(SetorRepository repository) {
        this.repository = repository;
    }

    public Setor salvar(Setor obj) {
        return repository.save(obj);
    }

    public List<Setor> listar() {
        return repository.findAll();
    }

    public Setor buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado"));
    }

    public Setor atualizar(Long id, Setor obj) {
        obj.setId(id);
        return repository.save(obj);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}

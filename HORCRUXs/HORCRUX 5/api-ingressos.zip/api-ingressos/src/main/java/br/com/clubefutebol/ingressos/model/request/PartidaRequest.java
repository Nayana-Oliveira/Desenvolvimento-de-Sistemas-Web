package br.com.clubefutebol.ingressos.model.request;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PartidaRequest {

    private String timeCasa;
    private String timeVisitante;
    private LocalDateTime data;
    private Long setorId;
}
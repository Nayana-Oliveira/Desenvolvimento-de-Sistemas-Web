package br.com.clubefutebol.ingressos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.clubefutebol.ingressos.model.entity.Ingresso;

public interface IngressoRepository extends JpaRepository<Ingresso, Long> {
}

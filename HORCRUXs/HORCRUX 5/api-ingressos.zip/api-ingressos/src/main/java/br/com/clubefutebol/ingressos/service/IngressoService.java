package br.com.clubefutebol.ingressos.service;

import br.com.clubefutebol.ingressos.model.entity.Ingresso;
import br.com.clubefutebol.ingressos.repository.IngressoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class IngressoService {

    private final IngressoRepository repository;

    public IngressoService(IngressoRepository repository) {
        this.repository = repository;
    }

    public Ingresso salvar(Ingresso obj) {
        return repository.save(obj);
    }

    public List<Ingresso> listar() {
        return repository.findAll();
    }

    public Ingresso buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado"));
    }

    public Ingresso atualizar(Long id, Ingresso obj) {
        obj.setId(id);
        return repository.save(obj);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}

package br.com.clubefutebol.ingressos.controller;

import br.com.clubefutebol.ingressos.model.entity.Ingresso;
import br.com.clubefutebol.ingressos.service.IngressoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/ingressos")
public class IngressoController {

    private final IngressoService service;

    public IngressoController(IngressoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Ingresso> cadastrar(@RequestBody Ingresso obj) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj));
    }

    @GetMapping
    public ResponseEntity<List<Ingresso>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ingresso> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscar(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Ingresso> atualizar(@PathVariable Long id, @RequestBody Ingresso obj) {
        return ResponseEntity.ok(service.atualizar(id, obj));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        service.deletar(id);
        return ResponseEntity.noContent().build();
    }
}

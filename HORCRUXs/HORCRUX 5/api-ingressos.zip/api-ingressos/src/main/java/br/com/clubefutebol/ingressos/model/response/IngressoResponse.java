package br.com.clubefutebol.ingressos.model.response;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class IngressoResponse {

    private Long id;
    private String comprador;
    private String partida;
    private Integer quantidade;
}
package br.com.clubefutebol.ingressos.model.entity;
public enum Role { ADMIN, FUNCIONARIO, TREINADOR }

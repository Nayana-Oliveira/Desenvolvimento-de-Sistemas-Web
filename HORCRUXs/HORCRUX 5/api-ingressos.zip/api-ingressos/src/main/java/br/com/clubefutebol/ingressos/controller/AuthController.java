package br.com.clubefutebol.ingressos.controller;

import br.com.clubefutebol.ingressos.model.request.*;
import br.com.clubefutebol.ingressos.model.response.*;
import br.com.clubefutebol.ingressos.model.entity.Usuario;
import br.com.clubefutebol.ingressos.repository.UsuarioRepository;
import br.com.clubefutebol.ingressos.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import br.com.clubefutebol.ingressos.model.entity.Role;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager, JwtService jwtService) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<Usuario> register(@RequestBody RegisterRequest request) {
        Usuario u = new Usuario();

        u.setNome(request.nome());
        u.setEmail(request.email());
        u.setSenha(passwordEncoder.encode(request.senha()));

        u.setRole(Role.valueOf(request.role().toUpperCase()));

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(usuarioRepository.save(u));
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.email(), request.senha()));
        var usuario = usuarioRepository.findByEmail(request.email()).orElseThrow();
        return ResponseEntity.ok(new LoginResponse(jwtService.gerarToken(usuario)));
    }
}

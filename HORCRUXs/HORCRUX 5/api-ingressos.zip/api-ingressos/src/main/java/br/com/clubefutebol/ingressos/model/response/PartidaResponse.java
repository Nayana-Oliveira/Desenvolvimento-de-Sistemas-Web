package br.com.clubefutebol.ingressos.model.response;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PartidaResponse {

    private Long id;
    private String timeCasa;
    private String timeVisitante;
    private LocalDateTime data;
}
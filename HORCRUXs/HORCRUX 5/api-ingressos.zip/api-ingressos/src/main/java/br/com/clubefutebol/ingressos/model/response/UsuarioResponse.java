package br.com.clubefutebol.ingressos.model.response;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class UsuarioResponse {

    private Long id;
    private String nome;
    private String email;
}
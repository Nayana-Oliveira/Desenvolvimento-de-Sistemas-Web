package br.com.clubefutebol.ingressos.model.request;

public record RegisterRequest(
        String nome,
        String email,
        String senha,
        String role
        ) {

}

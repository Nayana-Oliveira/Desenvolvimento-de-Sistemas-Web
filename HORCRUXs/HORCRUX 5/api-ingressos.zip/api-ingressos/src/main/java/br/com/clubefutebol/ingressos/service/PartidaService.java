package br.com.clubefutebol.ingressos.service;

import br.com.clubefutebol.ingressos.model.entity.Partida;
import br.com.clubefutebol.ingressos.repository.PartidaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PartidaService {

    private final PartidaRepository repository;

    public PartidaService(PartidaRepository repository) {
        this.repository = repository;
    }

    public Partida salvar(Partida obj) {
        return repository.save(obj);
    }

    public List<Partida> listar() {
        return repository.findAll();
    }

    public Partida buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado"));
    }

    public Partida atualizar(Long id, Partida obj) {
        obj.setId(id);
        return repository.save(obj);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}

package br.com.clubefutebol.ingressos.model.request;
import lombok.Data;

@Data
public class SetorRequest {

    private String nome;
    private Double preco;
}
package br.com.clubefutebol.ingressos.model.response;

public record LoginResponse(
        String token
) {
}

package br.com.clubefutebol.ingressos.model.request;
import lombok.Data;


@Data
public class IngressoRequest {

    private Long usuarioId;
    private Long partidaId;
    private Integer quantidade;
}
package br.com.clubefutebol.ingressos.model.request;

public record LoginRequest(
        String email,
        String senha
) {
}

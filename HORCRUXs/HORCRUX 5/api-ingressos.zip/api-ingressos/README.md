# API de Ingressos - Clube de Futebol

API REST desenvolvida em Java com Spring Boot para gerenciamento de usuários, partidas, setores e ingressos de um clube de futebol.

## Tecnologias utilizadas

- Java
- Spring Boot
- Spring Security
- JWT
- Spring Data JPA
- MySQL
- Maven

## Funcionalidades

- Cadastro e login de usuários
- Autenticação com JWT
- Controle de acesso por perfil
- CRUD de usuários
- CRUD de partidas
- CRUD de setores
- CRUD de ingressos

## Perfis de usuário

A API possui os seguintes perfis:

```txt
ADMIN
FUNCIONARIO
TREINADOR
````

## Autenticação

As rotas de autenticação são públicas:

```txt
POST /auth/register
POST /auth/login
```

As demais rotas precisam de token JWT no cabeçalho:

```txt
Authorization: Bearer SEU_TOKEN
```

---

# Rotas da API

## Auth

### Cadastrar usuário

```http
POST /auth/register
```

Body:

```json
{
  "nome": "Nayana",
  "email": "nayana@email.com",
  "senha": "123456",
  "role": "ADMIN"
}
```

Resposta de sucesso:

```json
{
  "id": 1,
  "nome": "Nayana",
  "email": "nayana@email.com",
  "role": "ADMIN"
}
```

---

### Login

```http
POST /auth/login
```

Body:

```json
{
  "email": "nayana@email.com",
  "senha": "123456"
}
```

Resposta de sucesso:

```json
{
  "token": "eyJhbGciOi..."
}
```

---

## Setores

### Cadastrar setor

```http
POST /setores
```

Body:

```json
{
  "nome": "Arquibancada",
  "capacidade": 5000
}
```

### Listar setores

```http
GET /setores
```

### Buscar setor por ID

```http
GET /setores/1
```

### Atualizar setor

```http
PUT /setores/1
```

Body:

```json
{
  "nome": "Camarote",
  "capacidade": 1000
}
```

### Deletar setor

```http
DELETE /setores/1
```

---

## Partidas

### Cadastrar partida

```http
POST /partidas
```

Body:

```json
{
  "adversario": "Palmeiras",
  "dataPartida": "2026-06-10",
  "horario": "20:30:00",
  "localPartida": "Neo Química Arena"
}
```

### Listar partidas

```http
GET /partidas
```

### Buscar partida por ID

```http
GET /partidas/1
```

### Atualizar partida

```http
PUT /partidas/1
```

Body:

```json
{
  "adversario": "São Paulo",
  "dataPartida": "2026-06-15",
  "horario": "21:00:00",
  "localPartida": "Neo Química Arena"
}
```

### Deletar partida

```http
DELETE /partidas/1
```

---

## Ingressos

### Cadastrar ingresso

```http
POST /ingressos
```

Body:

```json
{
  "preco": 80.00,
  "statusIngresso": "DISPONIVEL",
  "partida": {
    "id": 1
  },
  "setor": {
    "id": 1
  }
}
```

### Listar ingressos

```http
GET /ingressos
```

### Buscar ingresso por ID

```http
GET /ingressos/1
```

### Atualizar ingresso

```http
PUT /ingressos/1
```

Body:

```json
{
  "preco": 120.00,
  "statusIngresso": "VENDIDO",
  "partida": {
    "id": 1
  },
  "setor": {
    "id": 1
  }
}
```

### Deletar ingresso

```http
DELETE /ingressos/1
```

---

# Como testar no Postman

1. Cadastre um usuário em `/auth/register`
2. Faça login em `/auth/login`
3. Copie o token retornado
4. Nas próximas requisições, vá em:

```txt
Authorization > Bearer Token
```

5. Cole o token
6. Teste as rotas de setores, partidas e ingressos

---

# Ordem recomendada de teste

```txt
1. POST /auth/register
2. POST /auth/login
3. POST /setores
4. POST /partidas
5. POST /ingressos
6. GET /setores
7. GET /partidas
8. GET /ingressos
```

---

# Status HTTP esperados

| Status                    | Significado                      |
| ------------------------- | -------------------------------- |
| 200 OK                    | Requisição realizada com sucesso |
| 201 Created               | Registro criado com sucesso      |
| 400 Bad Request           | Dados inválidos                  |
| 401 Unauthorized          | Token ausente ou inválido        |
| 403 Forbidden             | Sem permissão                    |
| 404 Not Found             | Registro não encontrado          |
| 500 Internal Server Error | Erro interno no servidor         |

---

# Observações

* Não envie valores de `role` diferentes de `ADMIN`, `FUNCIONARIO` ou `TREINADOR`.
* As rotas protegidas só funcionam com token JWT.
* Para criar ingresso, primeiro é necessário cadastrar uma partida e um setor.



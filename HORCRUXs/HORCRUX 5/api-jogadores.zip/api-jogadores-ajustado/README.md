# API Jogadores - Clube de Futebol ⚽

## 📌 Sobre o Projeto

Este projeto é uma API REST desenvolvida em Java utilizando Spring Boot e MySQL.
O sistema foi criado para gerenciar jogadores de um clube de futebol, permitindo o cadastro de:

- Jogadores
- Posições
- Contratos
- Usuários
- Autenticação JWT

A aplicação possui autenticação com Spring Security + JWT, protegendo os endpoints privados da API.

---

# 🚀 Tecnologias Utilizadas

- Java 17
- Spring Boot 3
- Spring Security
- JWT (JSON Web Token)
- Spring Data JPA
- Hibernate
- MySQL
- Maven
- Postman

---

# 📁 Estrutura do Projeto

```bash
src/main/java/com/example/api_jogadores
│
├── controller
│   ├── AuthController
│   ├── ContratoController
│   ├── JogadorController
│   └── PosicaoController
│
├── dto
│   ├── request
│   └── response
│
├── model
│   └── entity
│
├── repository
│
├── security
│   ├── JwtAuthFilter
│   ├── JwtService
│   └── SecurityConfig
│
├── service
│
└── ApiJogadoresApplication
```

---

# 🗄️ Banco de Dados

## Banco utilizado

MySQL

## Configuração do application.properties

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/api_jogadores
spring.datasource.username=root
spring.datasource.password=123456

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true

jwt.secret=SEU_SEGREDO_JWT_AQUI
jwt.expiration=86400000
```

---

# 🔐 Autenticação JWT

A API utiliza autenticação JWT.

## Fluxo de autenticação

1. Registrar usuário
2. Fazer login
3. Receber token JWT
4. Utilizar token nos endpoints protegidos

---

# 👤 Registro de Usuário

## Endpoint

```http
POST /auth/register
```

## Body

```json
{
  "nome": "Gabriel",
  "email": "gabriel@gmail.com",
  "senha": "123456",
  "role": "ADMIN"
}
```

---

# 🔑 Login

## Endpoint

```http
POST /auth/login
```

## Body

```json
{
  "email": "gabriel@gmail.com",
  "senha": "123456"
}
```

## Resposta

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9..."
}
```

---

# 🔒 Authorization no Postman

Nos endpoints protegidos:

1. Vá em Authorization
2. Escolha Bearer Token
3. Cole o token JWT

Ou manualmente:

```http
Authorization: Bearer SEU_TOKEN
```

---

# ⚽ Endpoints - Posição

## Criar posição

```http
POST /posicoes
```

## Body

```json
{
  "nome": "Atacante"
}
```

---

## Listar posições

```http
GET /posicoes
```

---

# 🧍 Endpoints - Jogador

## Criar jogador

```http
POST /jogadores
```

## Body

```json
{
  "nome": "Vinicius Junior",
  "idade": 24,
  "nacionalidade": "Brasileiro",
  "numeroCamisa": 7,
  "posicaoId": 1
}
```

---

## Listar jogadores

```http
GET /jogadores
```

---

## Buscar jogador por ID

```http
GET /jogadores/{id}
```

---

## Deletar jogador

```http
DELETE /jogadores/{id}
```

---

# 📄 Endpoints - Contrato

## Criar contrato

```http
POST /contratos
```

## Body

```json
{
  "salario": 950000.00,
  "dataInicio": "2026-06-01",
  "dataFim": "2029-06-01",
  "jogadorId": 1
}
```

---

## Listar contratos

```http
GET /contratos
```

---

## Buscar contrato por ID

```http
GET /contratos/{id}
```

---

## Deletar contrato

```http
DELETE /contratos/{id}
```

---

# 🧱 Modelagem do Projeto

## Entidades

### Usuario

Responsável pela autenticação do sistema.

Campos:

- id
- nome
- email
- senha
- role

---

### Jogador

Representa um jogador do clube.

Campos:

- id
- nome
- idade
- nacionalidade
- numeroCamisa
- posicao

---

### Posicao

Representa a posição do jogador em campo.

Campos:

- id
- nome

---

### Contrato

Representa o contrato de um jogador.

Campos:

- id
- salario
- dataInicio
- dataFim
- jogador

---

# 📦 DTOs

O projeto utiliza DTOs separados em:

## request

Utilizados para entrada de dados.

Exemplos:

- JogadorRequest
- ContratoRequest
- LoginRequest
- RegisterRequest

---

## response

Utilizados para saída de dados.

Exemplos:

- JogadorResponse
- ContratoResponse
- LoginResponse

---

# 🛡️ Segurança

A segurança da aplicação foi implementada utilizando:

- Spring Security
- JWT
- Filtro personalizado JwtAuthFilter
- Roles (ADMIN / USER)

---

# ▶️ Como Executar o Projeto

## 1. Clonar o repositório

```bash
git clone URL_DO_REPOSITORIO
```

---

## 2. Abrir o projeto

Abrir no IntelliJ IDEA ou VSCode.

---

## 3. Configurar o banco MySQL

Criar banco:

```sql
CREATE DATABASE api_jogadores;
```

---

## 4. Rodar a aplicação

```bash
mvn spring-boot:run
```

---

# 🧪 Testes

Os testes da API podem ser realizados utilizando:

- Postman
- Insomnia
- Swagger

---

# 👨‍💻 Autor

Gabriel Groppo



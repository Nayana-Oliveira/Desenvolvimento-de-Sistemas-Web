package com.example.api_jogadores.model.entity;
public enum Role { ADMIN, USER }

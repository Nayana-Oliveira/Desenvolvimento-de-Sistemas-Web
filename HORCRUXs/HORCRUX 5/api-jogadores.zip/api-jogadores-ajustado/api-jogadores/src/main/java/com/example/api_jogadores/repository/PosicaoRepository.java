package com.example.api_jogadores.repository;
import com.example.api_jogadores.model.entity.Posicao;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PosicaoRepository extends JpaRepository<Posicao, Long> {}

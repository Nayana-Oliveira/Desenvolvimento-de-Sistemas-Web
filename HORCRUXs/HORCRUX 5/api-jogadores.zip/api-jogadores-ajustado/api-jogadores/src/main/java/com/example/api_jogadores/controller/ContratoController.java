package com.example.api_jogadores.controller;

import com.example.api_jogadores.dto.request.ContratoRequest;
import com.example.api_jogadores.dto.response.ContratoResponse;
import com.example.api_jogadores.model.entity.Contrato;
import com.example.api_jogadores.model.entity.Jogador;
import com.example.api_jogadores.repository.ContratoRepository;
import com.example.api_jogadores.repository.JogadorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contratos")
public class ContratoController {

    private final ContratoRepository contratoRepository;
    private final JogadorRepository jogadorRepository;

    public ContratoController(
            ContratoRepository contratoRepository,
            JogadorRepository jogadorRepository
    ) {
        this.contratoRepository = contratoRepository;
        this.jogadorRepository = jogadorRepository;
    }

    @PostMapping
    public ResponseEntity<ContratoResponse> salvar(
            @RequestBody ContratoRequest request
    ) {

        Jogador jogador = jogadorRepository
                .findById(request.getJogadorId())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Jogador não encontrado"
                        )
                );

        Contrato contrato = new Contrato();

        contrato.setSalario(request.getSalario());
        contrato.setDataInicio(request.getDataInicio());
        contrato.setDataFim(request.getDataFim());
        contrato.setJogador(jogador);

        Contrato salvo =
                contratoRepository.save(contrato);

        return ResponseEntity.ok(
                converterParaResponse(salvo)
        );
    }

    @GetMapping
    public ResponseEntity<List<ContratoResponse>> listar() {

        List<ContratoResponse> lista =
                contratoRepository.findAll()
                        .stream()
                        .map(this::converterParaResponse)
                        .toList();

        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ContratoResponse> buscarPorId(
            @PathVariable Long id
    ) {

        Contrato contrato =
                contratoRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Contrato não encontrado"
                                )
                        );

        return ResponseEntity.ok(
                converterParaResponse(contrato)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(
            @PathVariable Long id
    ) {

        contratoRepository.deleteById(id);

        return ResponseEntity.noContent().build();
    }

    private ContratoResponse converterParaResponse(
            Contrato contrato
    ) {

        ContratoResponse response =
                new ContratoResponse();

        response.setId(contrato.getId());

        response.setSalario(
                contrato.getSalario()
        );

        response.setDataInicio(
                contrato.getDataInicio()
        );

        response.setDataFim(
                contrato.getDataFim()
        );

        if (contrato.getJogador() != null) {

            response.setJogadorId(
                    contrato.getJogador().getId()
            );

            response.setNomeJogador(
                    contrato.getJogador().getNome()
            );
        }

        return response;
    }
}
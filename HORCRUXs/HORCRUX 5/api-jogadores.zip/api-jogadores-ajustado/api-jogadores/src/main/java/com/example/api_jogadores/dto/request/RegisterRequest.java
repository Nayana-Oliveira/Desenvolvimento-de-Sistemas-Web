package com.example.api_jogadores.dto.request;
import com.example.api_jogadores.model.entity.Role;
public record RegisterRequest(String nome, String email, String senha, Role role) {}

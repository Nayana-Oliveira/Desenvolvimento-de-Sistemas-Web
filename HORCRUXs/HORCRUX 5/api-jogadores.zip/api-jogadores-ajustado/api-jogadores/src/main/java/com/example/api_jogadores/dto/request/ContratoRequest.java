package com.example.api_jogadores.dto.request;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ContratoRequest {

    private BigDecimal salario;

    private LocalDate dataInicio;

    private LocalDate dataFim;

    private Long jogadorId;

    public ContratoRequest() {
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public Long getJogadorId() {
        return jogadorId;
    }

    public void setJogadorId(Long jogadorId) {
        this.jogadorId = jogadorId;
    }
}
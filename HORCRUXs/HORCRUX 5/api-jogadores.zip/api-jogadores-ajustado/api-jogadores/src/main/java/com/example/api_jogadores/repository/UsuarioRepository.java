package com.example.api_jogadores.repository;
import com.example.api_jogadores.model.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface UsuarioRepository extends JpaRepository<Usuario, Long> { Optional<Usuario> findByEmail(String email); }

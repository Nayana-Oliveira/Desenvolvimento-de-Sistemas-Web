package com.example.api_jogadores.repository;
import com.example.api_jogadores.model.entity.Contrato;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ContratoRepository extends JpaRepository<Contrato, Long> {}

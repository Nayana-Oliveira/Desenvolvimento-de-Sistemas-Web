package com.example.api_jogadores.dto.response;
public class JogadorResponse {
    public Long id;
    public String nome;
    public Integer idade;
    public String nacionalidade;
    public Integer numeroCamisa;
    public String posicao;
}

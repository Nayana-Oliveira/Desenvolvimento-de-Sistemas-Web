package com.example.api_jogadores.dto.response;
public record LoginResponse(String token) {}

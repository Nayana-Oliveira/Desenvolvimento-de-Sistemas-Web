package com.example.api_jogadores.controller;
import com.example.api_jogadores.model.entity.Posicao;
import com.example.api_jogadores.service.PosicaoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/posicoes")
public class PosicaoController {
    private final PosicaoService service;
    public PosicaoController(PosicaoService service) { this.service = service; }
    @PostMapping public ResponseEntity<Posicao> cadastrar(@RequestBody Posicao obj) { return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj)); }
    @GetMapping public ResponseEntity<List<Posicao>> listar() { return ResponseEntity.ok(service.listar()); }
    @GetMapping("/{id}") public ResponseEntity<Posicao> buscar(@PathVariable Long id) { return ResponseEntity.ok(service.buscar(id)); }
    @PutMapping("/{id}") public ResponseEntity<Posicao> atualizar(@PathVariable Long id, @RequestBody Posicao obj) { return ResponseEntity.ok(service.atualizar(id, obj)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> deletar(@PathVariable Long id) { service.deletar(id); return ResponseEntity.noContent().build(); }
}

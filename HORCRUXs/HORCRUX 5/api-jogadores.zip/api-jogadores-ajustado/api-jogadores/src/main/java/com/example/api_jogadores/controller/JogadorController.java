package com.example.api_jogadores.controller;
import com.example.api_jogadores.model.entity.Jogador;
import com.example.api_jogadores.service.JogadorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/jogadores")
public class JogadorController {
    private final JogadorService service;
    public JogadorController(JogadorService service) { this.service = service; }
    @PostMapping public ResponseEntity<Jogador> cadastrar(@RequestBody Jogador obj) { return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj)); }
    @GetMapping public ResponseEntity<List<Jogador>> listar() { return ResponseEntity.ok(service.listar()); }
    @GetMapping("/{id}") public ResponseEntity<Jogador> buscar(@PathVariable Long id) { return ResponseEntity.ok(service.buscar(id)); }
    @PutMapping("/{id}") public ResponseEntity<Jogador> atualizar(@PathVariable Long id, @RequestBody Jogador obj) { return ResponseEntity.ok(service.atualizar(id, obj)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> deletar(@PathVariable Long id) { service.deletar(id); return ResponseEntity.noContent().build(); }
}

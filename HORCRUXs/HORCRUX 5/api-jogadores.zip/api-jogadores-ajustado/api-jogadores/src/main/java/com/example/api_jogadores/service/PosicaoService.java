package com.example.api_jogadores.service;
import com.example.api_jogadores.model.entity.Posicao;
import com.example.api_jogadores.repository.PosicaoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class PosicaoService {
    private final PosicaoRepository repository;
    public PosicaoService(PosicaoRepository repository) { this.repository = repository; }
    public Posicao salvar(Posicao obj) { return repository.save(obj); }
    public List<Posicao> listar() { return repository.findAll(); }
    public Posicao buscar(Long id) { return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado")); }
    public Posicao atualizar(Long id, Posicao obj) { obj.setId(id); return repository.save(obj); }
    public void deletar(Long id) { repository.deleteById(id); }
}

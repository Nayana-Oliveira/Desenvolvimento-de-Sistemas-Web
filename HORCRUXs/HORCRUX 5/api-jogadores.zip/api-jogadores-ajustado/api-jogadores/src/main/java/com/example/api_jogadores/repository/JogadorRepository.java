package com.example.api_jogadores.repository;
import com.example.api_jogadores.model.entity.Jogador;
import org.springframework.data.jpa.repository.JpaRepository;
public interface JogadorRepository extends JpaRepository<Jogador, Long> {}

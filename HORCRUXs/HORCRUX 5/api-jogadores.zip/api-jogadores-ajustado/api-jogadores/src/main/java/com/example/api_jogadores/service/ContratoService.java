package com.example.api_jogadores.service;
import com.example.api_jogadores.model.entity.Contrato;
import com.example.api_jogadores.repository.ContratoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class ContratoService {
    private final ContratoRepository repository;
    public ContratoService(ContratoRepository repository) { this.repository = repository; }
    public Contrato salvar(Contrato obj) { return repository.save(obj); }
    public List<Contrato> listar() { return repository.findAll(); }
    public Contrato buscar(Long id) { return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado")); }
    public Contrato atualizar(Long id, Contrato obj) { obj.setId(id); return repository.save(obj); }
    public void deletar(Long id) { repository.deleteById(id); }
}

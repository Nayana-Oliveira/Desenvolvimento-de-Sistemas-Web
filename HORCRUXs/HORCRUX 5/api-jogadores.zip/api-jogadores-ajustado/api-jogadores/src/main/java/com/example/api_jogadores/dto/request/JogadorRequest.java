package com.example.api_jogadores.dto.request;
public class JogadorRequest {
    public String nome;
    public Integer idade;
    public String nacionalidade;
    public Integer numeroCamisa;
    public Long posicaoId;
}

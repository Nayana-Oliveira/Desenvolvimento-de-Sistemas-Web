package com.example.api_jogadores.dto.request;
public record LoginRequest(String email, String senha) {}

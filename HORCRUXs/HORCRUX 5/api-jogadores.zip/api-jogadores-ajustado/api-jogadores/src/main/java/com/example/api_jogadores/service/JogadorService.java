package com.example.api_jogadores.service;
import com.example.api_jogadores.model.entity.Jogador;
import com.example.api_jogadores.repository.JogadorRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class JogadorService {
    private final JogadorRepository repository;
    public JogadorService(JogadorRepository repository) { this.repository = repository; }
    public Jogador salvar(Jogador obj) { return repository.save(obj); }
    public List<Jogador> listar() { return repository.findAll(); }
    public Jogador buscar(Long id) { return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado")); }
    public Jogador atualizar(Long id, Jogador obj) { obj.setId(id); return repository.save(obj); }
    public void deletar(Long id) { repository.deleteById(id); }
}

# API Patrimônio/Estádio

CRUD de setores do estádio, equipamentos e manutenções. Swagger: http://localhost:5015/swagger-ui.html

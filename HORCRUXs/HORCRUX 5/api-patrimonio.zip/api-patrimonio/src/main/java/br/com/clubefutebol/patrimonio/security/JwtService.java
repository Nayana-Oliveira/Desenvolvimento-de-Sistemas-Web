package br.com.clubefutebol.patrimonio.security;

// import io.jsonwebtoken.Claims;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
    @Value("${jwt.secret}") private String secret;
    @Value("${jwt.expiration}") private Long expiration;
    private SecretKey getKey() { return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)); }
    public String gerarToken(UserDetails user) {
        return Jwts.builder().subject(user.getUsername()).issuedAt(new Date()).expiration(new Date(System.currentTimeMillis()+expiration)).signWith(getKey()).compact();
    }
    public String extrairEmail(String token) { return Jwts.parser().verifyWith(getKey()).build().parseSignedClaims(token).getPayload().getSubject(); }
    public boolean tokenValido(String token, UserDetails user) { return extrairEmail(token).equals(user.getUsername()); }
}

package br.com.clubefutebol.patrimonio.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.clubefutebol.patrimonio.model.entity.Manutencao;
public interface ManutencaoRepository extends JpaRepository<Manutencao, Long> {}

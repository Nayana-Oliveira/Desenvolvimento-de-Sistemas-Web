package br.com.clubefutebol.patrimonio.model.entity;
public enum Role { ADMIN, FUNCIONARIO, TREINADOR }

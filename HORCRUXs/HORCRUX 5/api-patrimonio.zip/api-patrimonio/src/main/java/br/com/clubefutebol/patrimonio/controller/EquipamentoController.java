package br.com.clubefutebol.patrimonio.controller;
import br.com.clubefutebol.patrimonio.model.entity.Equipamento;
import br.com.clubefutebol.patrimonio.service.EquipamentoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/equipamentos")
public class EquipamentoController {
    private final EquipamentoService service;
    public EquipamentoController(EquipamentoService service) { this.service = service; }
    @PostMapping public ResponseEntity<Equipamento> cadastrar(@RequestBody Equipamento obj) { return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj)); }
    @GetMapping public ResponseEntity<List<Equipamento>> listar() { return ResponseEntity.ok(service.listar()); }
    @GetMapping("/{id}") public ResponseEntity<Equipamento> buscar(@PathVariable Long id) { return ResponseEntity.ok(service.buscar(id)); }
    @PutMapping("/{id}") public ResponseEntity<Equipamento> atualizar(@PathVariable Long id, @RequestBody Equipamento obj) { return ResponseEntity.ok(service.atualizar(id, obj)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> deletar(@PathVariable Long id) { service.deletar(id); return ResponseEntity.noContent().build(); }
}

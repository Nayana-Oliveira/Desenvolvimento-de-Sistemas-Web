package br.com.clubefutebol.patrimonio.service;
import br.com.clubefutebol.patrimonio.model.entity.Manutencao;
import br.com.clubefutebol.patrimonio.repository.ManutencaoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class ManutencaoService {
    private final ManutencaoRepository repository;
    public ManutencaoService(ManutencaoRepository repository) { this.repository = repository; }
    public Manutencao salvar(Manutencao obj) { return repository.save(obj); }
    public List<Manutencao> listar() { return repository.findAll(); }
    public Manutencao buscar(Long id) { return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado")); }
    public Manutencao atualizar(Long id, Manutencao obj) { obj.setId(id); return repository.save(obj); }
    public void deletar(Long id) { repository.deleteById(id); }
}

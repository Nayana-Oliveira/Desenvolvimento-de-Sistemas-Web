package br.com.clubefutebol.patrimonio.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.clubefutebol.patrimonio.model.entity.Equipamento;
public interface EquipamentoRepository extends JpaRepository<Equipamento, Long> {}

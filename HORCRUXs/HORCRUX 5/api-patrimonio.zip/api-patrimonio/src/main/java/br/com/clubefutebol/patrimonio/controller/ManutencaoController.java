package br.com.clubefutebol.patrimonio.controller;
import br.com.clubefutebol.patrimonio.model.entity.Manutencao;
import br.com.clubefutebol.patrimonio.service.ManutencaoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/manutencoes")
public class ManutencaoController {
    private final ManutencaoService service;
    public ManutencaoController(ManutencaoService service) { this.service = service; }
    @PostMapping public ResponseEntity<Manutencao> cadastrar(@RequestBody Manutencao obj) { return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj)); }
    @GetMapping public ResponseEntity<List<Manutencao>> listar() { return ResponseEntity.ok(service.listar()); }
    @GetMapping("/{id}") public ResponseEntity<Manutencao> buscar(@PathVariable Long id) { return ResponseEntity.ok(service.buscar(id)); }
    @PutMapping("/{id}") public ResponseEntity<Manutencao> atualizar(@PathVariable Long id, @RequestBody Manutencao obj) { return ResponseEntity.ok(service.atualizar(id, obj)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> deletar(@PathVariable Long id) { service.deletar(id); return ResponseEntity.noContent().build(); }
}

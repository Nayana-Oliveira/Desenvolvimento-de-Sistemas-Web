package br.com.clubefutebol.patrimonio.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import br.com.clubefutebol.patrimonio.model.entity.SetorEstadio;
public interface SetorEstadioRepository extends JpaRepository<SetorEstadio, Long> {}

package br.com.clubefutebol.patrimonio.service;
import br.com.clubefutebol.patrimonio.model.entity.SetorEstadio;
import br.com.clubefutebol.patrimonio.repository.SetorEstadioRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class SetorEstadioService {
    private final SetorEstadioRepository repository;
    public SetorEstadioService(SetorEstadioRepository repository) { this.repository = repository; }
    public SetorEstadio salvar(SetorEstadio obj) { return repository.save(obj); }
    public List<SetorEstadio> listar() { return repository.findAll(); }
    public SetorEstadio buscar(Long id) { return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado")); }
    public SetorEstadio atualizar(Long id, SetorEstadio obj) { obj.setId(id); return repository.save(obj); }
    public void deletar(Long id) { repository.deleteById(id); }
}

package br.com.clubefutebol.patrimonio.model.request;
public record LoginRequest(String email, String senha) {}

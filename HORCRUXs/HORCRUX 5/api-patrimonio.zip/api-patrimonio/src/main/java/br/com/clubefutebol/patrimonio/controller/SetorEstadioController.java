package br.com.clubefutebol.patrimonio.controller;
import br.com.clubefutebol.patrimonio.model.entity.SetorEstadio;
import br.com.clubefutebol.patrimonio.service.SetorEstadioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/setores-estadio")
public class SetorEstadioController {
    private final SetorEstadioService service;
    public SetorEstadioController(SetorEstadioService service) { this.service = service; }
    @PostMapping public ResponseEntity<SetorEstadio> cadastrar(@RequestBody SetorEstadio obj) { return ResponseEntity.status(HttpStatus.CREATED).body(service.salvar(obj)); }
    @GetMapping public ResponseEntity<List<SetorEstadio>> listar() { return ResponseEntity.ok(service.listar()); }
    @GetMapping("/{id}") public ResponseEntity<SetorEstadio> buscar(@PathVariable Long id) { return ResponseEntity.ok(service.buscar(id)); }
    @PutMapping("/{id}") public ResponseEntity<SetorEstadio> atualizar(@PathVariable Long id, @RequestBody SetorEstadio obj) { return ResponseEntity.ok(service.atualizar(id, obj)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> deletar(@PathVariable Long id) { service.deletar(id); return ResponseEntity.noContent().build(); }
}

package br.com.clubefutebol.patrimonio.model.request;
import br.com.clubefutebol.patrimonio.model.entity.Role;
public record RegisterRequest(String nome, String email, String senha, Role role) {}

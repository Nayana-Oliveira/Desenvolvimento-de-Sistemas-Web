package br.com.clubefutebol.patrimonio.model.response;
public record LoginResponse(String token) {}

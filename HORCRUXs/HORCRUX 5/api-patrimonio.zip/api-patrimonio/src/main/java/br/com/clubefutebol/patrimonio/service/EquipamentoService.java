package br.com.clubefutebol.patrimonio.service;
import br.com.clubefutebol.patrimonio.model.entity.Equipamento;
import br.com.clubefutebol.patrimonio.repository.EquipamentoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class EquipamentoService {
    private final EquipamentoRepository repository;
    public EquipamentoService(EquipamentoRepository repository) { this.repository = repository; }
    public Equipamento salvar(Equipamento obj) { return repository.save(obj); }
    public List<Equipamento> listar() { return repository.findAll(); }
    public Equipamento buscar(Long id) { return repository.findById(id).orElseThrow(() -> new RuntimeException("Registro não encontrado")); }
    public Equipamento atualizar(Long id, Equipamento obj) { obj.setId(id); return repository.save(obj); }
    public void deletar(Long id) { repository.deleteById(id); }
}
